package model;
import java.util.Scanner;
import Telas.telaInicial;

public class Main {
	public static void main(String[] args) {
	

telaInicial TelaInicial = new telaInicial();

TelaInicial.setVisible(true);;
	}


}
