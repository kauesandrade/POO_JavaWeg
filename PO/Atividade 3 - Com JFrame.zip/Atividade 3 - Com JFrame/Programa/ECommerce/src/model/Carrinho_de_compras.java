package model;

public class Carrinho_de_compras {

	private Cliente cliente;
// private ArrayList<String> telefone = new telefone
	
	private int quantidade;
	
	
	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
//		this.cliente.add(cliente);
	}
	
	public void adicionarProduto() {
		
	}
	
	
	
	
}
